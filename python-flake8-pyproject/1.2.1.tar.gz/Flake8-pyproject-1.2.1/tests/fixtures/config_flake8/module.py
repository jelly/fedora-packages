﻿"""This line is 77 characters long, less than the default max-line-length."""

import foo

missing_space   = (None,None)
multiple_spaces = (None, None)
