﻿## Test suite

The scripts here, along with the fixtures, constitute the test suite.
Run them with `pytest` from the root folder. Or use the scripts
`test.py` and `coverage.py` from the `tools` folder.
