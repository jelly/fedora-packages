﻿"""Meta information about the package."""

title     = 'Flake8-pyproject'
synopsis  = 'Flake8 plug-in loading the configuration from pyproject.toml'
version   = '1.2.1'
author    = 'John Hennig'
license   = 'MIT'
